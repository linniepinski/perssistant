<?php 
/**
 * Template Name: Register Page Template
*/


global $user_ID;

// user already login redirect to home page

if($user_ID) {

    // isset redirect url

    if(isset($_REQUEST['redirect'])) {

        wp_redirect($_REQUEST['redirect']);

        exit;

    }

    wp_redirect(home_url());

    exit;

}

if($_GET['c_user_email']){
	wp_mail( $_GET['c_user_email'], 'E-mail confirmation', 'http://'.$_SERVER["HTTP_HOST"].'/sign-up/?email='.$_GET['c_user_email'] );	
}

get_header();

?>



<!-- Breadcrumb Blog -->
<?php /*
<div class="section-detail-wrapper breadcrumb-blog-page">

    <ol class="breadcrumb">

        <li><a href="<?php echo home_url() ?>" title="<?php echo get_bloginfo( 'name' ); ?>" ><?php _e("Home", ET_DOMAIN); ?></a></li>

        <li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>

    </ol>

</div>
*/?>
<!-- Breadcrumb Blog / End -->



<section class="blog-header-container">

	<div class="container">

		<!-- blog header -->

		<div class="row">

		    <div class="col-md-12 blog-classic-top">

		        <h2><?php the_title(); ?></h2>

		    </div>

		</div>      

		<!--// blog header  -->	

	</div>

</section>



<div class="container page-container">

	<!-- block control  -->

	<div class="row block-posts block-page">

		<div class="col-md-12 col-sm-12 col-xs-12 posts-container" id="left_content">

            <div class="blog-content">
				<input type="hidden" value="<?php _e("Work", ET_DOMAIN); ?>" class="work-text" name="worktext" />

				<input type="hidden" value="<?php _e("Hire", ET_DOMAIN); ?>" class="hide-text" name="hidetext" />
				
				<?php if($_GET['c_user_email']){ ?><center><?php echo 'Email sended to '.$_GET['c_user_email']; ?></center><?php } ?>
				
				<?php if(!$_GET['email'] && !$_GET['c_user_email']){ ?>				
				<form role="form" id="user_confirm_form" class="auth-form signup_form">
					
					<div class="form-group">

						<label for="register_user_email"><?php _e('Email address', ET_DOMAIN) ?></label>

						<input type="email" class="form-control" id="conf_user_email" name="c_user_email" placeholder="<?php _e("Enter email", ET_DOMAIN) ?>">

					</div>
					
					
					<button type="submit" class="btn-submit btn-sumary btn-sub-create">

						<?php _e('Confirm E-mail', ET_DOMAIN) ?>

					</button>
			    </form><?php } ?>

                <form role="form" id="user_signup_form" class="auth-form signup_form">
					<?php if($_GET['email']){ ?>
                	<p class="user-type">

                		<?php _e("What are you looking for?", ET_DOMAIN) ?> 



                            <input type="checkbox" class="sign-up-switch" name="modal-check" id="modal-check"/>

                            <span class="user-role text work">

                                <?php _e("Work", ET_DOMAIN); ?>

                            </span>

                	</p>
					
                	<input type="hidden" name="role" id="role" value="freelancer" />

					<div class="form-group">

						<label for="user_login"><?php _e('Username', ET_DOMAIN) ?></label>

						<input type="text" class="form-control" id="user_login" name="user_login" placeholder="<?php _e("Enter username", ET_DOMAIN) ?>">

					</div>
					
					<div class="form-group">

						<label for="register_user_email"><?php _e('Email address: ', ET_DOMAIN);  echo $_GET['email'];  ?></label>

						<input  style="display:none;" type="email" class="form-control" id="register_user_email" name="user_email" placeholder="<?php _e("Enter email", ET_DOMAIN) ?>" value="<?php echo $_GET['email']; ?>">

					</div>
					
					<div class="form-group">

						<label for="register_user_pass"><?php _e('Password', ET_DOMAIN) ?></label>

						<input type="password" class="form-control" id="register_user_pass" name="user_pass" placeholder="<?php _e("Password", ET_DOMAIN) ?>">

					</div>

					<div class="form-group">

						<label for="repeat_pass"><?php _e('Retype Password', ET_DOMAIN) ?></label>

						<input type="password" class="form-control" id="repeat_pass" name="repeat_pass" placeholder="<?php _e("Retype password", ET_DOMAIN) ?>">

					</div>	

					<div class="clearfix"></div>

					<?php if(get_theme_mod( 'termofuse_checkbox', false )){ ?>

					<div class="form-group policy-agreement">

						<input name="agreement" id="agreement" type="checkbox" />

						<?php printf(__('I agree with the <a href="%s">Term of Use and Privacy policy</a>', ET_DOMAIN), et_get_page_link('tos') ); ?>

					</div>	

                    <div class="clearfix"></div>	

                    <?php } ?>

					<button type="submit" class="btn-submit btn-sumary btn-sub-create">

						<?php _e('Sign up', ET_DOMAIN) ?>

					</button><?php } ?>

					<?php if(!get_theme_mod( 'termofuse_checkbox', false )){ ?>

					<p class="text-term">

						<?php

		                /**

		                 * tos agreement

		                */

		                $tos = et_get_page_link('tos', array() ,false);

		                if($tos) { ?>

		                    <?php printf(__('By creating an account, you agree to our <a href="%s">Term of Use and Privacy policy</a>', ET_DOMAIN), et_get_page_link('tos') ); ?>

		                <?php } ?>

					</p>

					<?php } 

		                if( function_exists('ae_render_social_button')){

		                    $before_string = __("You can also sign in by:", ET_DOMAIN);

		                    ae_render_social_button( array(), array(), $before_string ); 

		                }

		            ?>

				</form>	           

				<div class="clearfix"></div>

            </div><!-- end page content -->

		</div><!-- LEFT CONTENT -->
		<?php /*
		<div class="col-md-3 col-sm-12 col-xs-12 page-sidebar" id="right_content">

			<?php get_sidebar('page'); ?>
			

		</div><!-- RIGHT CONTENT -->
		<?php */?>
	</div>

	<!--// block control  -->

</div>

<?php

	get_footer();

?>