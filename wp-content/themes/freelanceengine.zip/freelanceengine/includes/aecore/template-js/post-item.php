<span class="" style="background:<%= qa_badge_color %>; width:10px;height:10px;margin-right:10px;"></span>
<span>{{= post_title }}</span>  
{{= qa_point_text }}
<div class="actions">
	<a href="#" title="Edit" class="icon act-edit" rel="665" data-icon="p"></a>
	<a href="#" title="Delete" class="icon act-del" rel="665" data-icon="D"></a>
</div>					
