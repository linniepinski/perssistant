<script type="text/template" id="ae-portfolio-loop"> 	
	<a href="{{= the_post_thumbnail_full }}" title="{{= post_title }}" class="image-gallery">
		<img src="{{= the_post_thumbnail }}" >
	</a>
	<a href="#" class="delete">
		<i class="fa fa-trash-o"></i>
	</a>
</script>