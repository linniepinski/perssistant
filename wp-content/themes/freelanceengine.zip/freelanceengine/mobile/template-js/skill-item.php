<script type="text/template" id="skill_item">

	<input type="hidden" name="skills[]" value="{{= name }}" class="skill-input" />
	{{= name }} <a href="javascript:void(0);" class="delete"><i class="fa fa-times"></i></a>
	
</script>