<script type="text/template" id="header_login_template">
	<a href="<?php echo et_get_page_link('profile'); ?>#tab_notification" class="trigger-notification" >
        <span class="flag-icon">
            <i class="fa fa-flag-o"></i>
        </span>
    </a>
    <a href="<?php echo et_get_page_link('profile'); ?>" class="logged-in" class="logged-in">
        {{= avatar }}
    </a>
</script>