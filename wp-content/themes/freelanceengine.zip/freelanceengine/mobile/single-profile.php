<?php
	et_get_mobile_header();
?>
<?php
	et_get_mobile_footer();
?>